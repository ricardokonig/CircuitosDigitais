module top_level (
    input clk,             // Clock 50 MHz
    input [7:0] D,         // Dado (8 chaves)
    input [1:0] Sel,       // Seletor (2 chaves)
    output [6:0] hex1,     // Display bits mais significativos
    output [6:0] hex0      // Display bits menos significativos
);
    wire clk_div;
    wire [7:0] Q_out;

    ClockDiv div_inst (.clk_in(clk), .clk_out(clk_div));
    contador_8b cont_inst (.clk(clk_div), .D(D), .Sel(Sel), .Q(Q_out));
    BCD_7seg disp_alto (.bcd_in(Q_out[7:4]), .seg_out(hex1));
    BCD_7seg disp_baixo (.bcd_in(Q_out[3:0]), .seg_out(hex0));
endmodule