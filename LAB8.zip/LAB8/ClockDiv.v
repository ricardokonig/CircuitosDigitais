module ClockDiv (
    input clk_in,
    output reg clk_out
);
    reg [24:0] contador;
    initial begin contador = 0; clk_out = 0; end

    always @(posedge clk_in) begin
        if (contador == 25'd24_999_999) begin
            contador <= 0;
            clk_out <= ~clk_out;
        end else begin
            contador <= contador + 1'b1;
        end
    end
endmodule