library verilog;
use verilog.vl_types.all;
entity top_level_vlg_sample_tst is
    port(
        D               : in     vl_logic_vector(7 downto 0);
        Sel             : in     vl_logic_vector(1 downto 0);
        clk             : in     vl_logic;
        sampler_tx      : out    vl_logic
    );
end top_level_vlg_sample_tst;
