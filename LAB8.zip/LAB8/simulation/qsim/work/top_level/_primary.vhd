library verilog;
use verilog.vl_types.all;
entity top_level is
    port(
        clk             : in     vl_logic;
        D               : in     vl_logic_vector(7 downto 0);
        Sel             : in     vl_logic_vector(1 downto 0);
        hex1            : out    vl_logic_vector(6 downto 0);
        hex0            : out    vl_logic_vector(6 downto 0)
    );
end top_level;
