module d_ff(input clk, input d, output reg q);
    always @(posedge clk) q <= d;
endmodule

module mux4x1(input i0, i1, i2, i3, input s0, s1, output out);
    wire ns0, ns1, w0, w1, w2, w3;
    not (ns0, s0); not (ns1, s1);
    and (w0, i0, ns1, ns0);
    and (w1, i1, ns1, s0);
    and (w2, i2, s1, ns0);
    and (w3, i3, s1, s0);
    or (out, w0, w1, w2, w3);
endmodule