module bit_slice(
    input clk, input D, input [1:0] Sel, input Cin,
    output Cout, output Q
);
    wire w_Q, not_Q, not_Sel0, w_inc_dec, w_carry_inc, w_carry_dec, w_c1, w_c2, w_mux_out;

    xor (w_inc_dec, w_Q, Cin);
    and (w_carry_inc, w_Q, Cin);
    
    not (not_Q, w_Q);
    and (w_carry_dec, not_Q, Cin);

    not (not_Sel0, Sel[0]);
    and (w_c1, Sel[0], w_carry_dec);
    and (w_c2, not_Sel0, w_carry_inc);
    or  (Cout, w_c1, w_c2);

    mux4x1 m_operacao (.i0(D), .i1(w_Q), .i2(w_inc_dec), .i3(w_inc_dec), .s0(Sel[0]), .s1(Sel[1]), .out(w_mux_out));
    d_ff ff_inst (.clk(clk), .d(w_mux_out), .q(w_Q));
    assign Q = w_Q;
endmodule

module contador_8b(
    input clk, input [7:0] D, input [1:0] Sel, output [7:0] Q
);
    wire c0, c1, c2, c3, c4, c5, c6, c7;
    bit_slice b0(.clk(clk), .D(D[0]), .Sel(Sel), .Cin(1'b1), .Cout(c0), .Q(Q[0]));
    bit_slice b1(.clk(clk), .D(D[1]), .Sel(Sel), .Cin(c0),   .Cout(c1), .Q(Q[1]));
    bit_slice b2(.clk(clk), .D(D[2]), .Sel(Sel), .Cin(c1),   .Cout(c2), .Q(Q[2]));
    bit_slice b3(.clk(clk), .D(D[3]), .Sel(Sel), .Cin(c2),   .Cout(c3), .Q(Q[3]));
    bit_slice b4(.clk(clk), .D(D[4]), .Sel(Sel), .Cin(c3),   .Cout(c4), .Q(Q[4]));
    bit_slice b5(.clk(clk), .D(D[5]), .Sel(Sel), .Cin(c4),   .Cout(c5), .Q(Q[5]));
    bit_slice b6(.clk(clk), .D(D[6]), .Sel(Sel), .Cin(c5),   .Cout(c6), .Q(Q[6]));
    bit_slice b7(.clk(clk), .D(D[7]), .Sel(Sel), .Cin(c6),   .Cout(c7), .Q(Q[7]));
endmodule