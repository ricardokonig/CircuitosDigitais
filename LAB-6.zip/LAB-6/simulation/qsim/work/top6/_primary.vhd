library verilog;
use verilog.vl_types.all;
entity top6 is
    port(
        sw              : in     vl_logic_vector(9 downto 0);
        hex0_d          : out    vl_logic_vector(6 downto 0);
        flag_z          : out    vl_logic;
        flag_n          : out    vl_logic
    );
end top6;
