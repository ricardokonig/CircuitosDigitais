library verilog;
use verilog.vl_types.all;
entity LAB_5 is
    port(
        clk_out         : out    vl_logic;
        reset           : in     vl_logic;
        clk_in          : in     vl_logic
    );
end LAB_5;
