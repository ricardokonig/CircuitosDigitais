library verilog;
use verilog.vl_types.all;
entity LAB_5_vlg_check_tst is
    port(
        clk_out         : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end LAB_5_vlg_check_tst;
