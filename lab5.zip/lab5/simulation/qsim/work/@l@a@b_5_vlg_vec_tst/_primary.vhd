library verilog;
use verilog.vl_types.all;
entity LAB_5_vlg_vec_tst is
end LAB_5_vlg_vec_tst;
