vlog -work work C:/Users/ricar/Desktop/labcinco/simulation/modelsim/Waveform.vwf.vt
vsim -novopt -c -t 1ps -L cycloneiv_ver -L altera_ver -L altera_mf_ver -L 220model_ver -L sgate work.LAB_5_vlg_vec_tst
onerror {resume}
add wave {LAB_5_vlg_vec_tst/i1/clk_in}
add wave {LAB_5_vlg_vec_tst/i1/clk_out}
add wave {LAB_5_vlg_vec_tst/i1/reset}
run -all
